﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upr3.Data;
public enum UserRolesEnum
{
    ANONYMOUS, ADMIN, INSPECTOR, PROFESSOR, STUDENT
}


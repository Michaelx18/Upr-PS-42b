﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upr6.Helpers;
public enum UserRolesEnum
{
    ADMIN,
    USER,
    TEACHER
}
